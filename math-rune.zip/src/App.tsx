import React, { useState, useEffect } from 'react';
import { useGameSocket } from './hooks/useGameSocket.ts';
import { Header } from './components/Header.tsx';
import { MainMenu } from './components/MainMenu.tsx';
import { GameArena } from './components/GameArena.tsx';
import { OnlineLobby } from './components/OnlineLobby.tsx';
import { DeckViewer } from './components/DeckViewer.tsx';
import { RuneGrimoire } from './components/RuneGrimoire.tsx';
import { ProfileView } from './components/ProfileView.tsx';
import { LeaderboardView } from './components/LeaderboardView.tsx';
import { AdminPanel } from './components/AdminPanel.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { HowToPlayModal } from './components/HowToPlayModal.tsx';
import { ThemeModal } from './components/ThemeModal.tsx';
import { AtmosphericBackground } from './components/AtmosphericBackground.tsx';
import { getSavedTheme, saveTheme, ThemeDef, GAME_THEMES } from './utils/themeManager.ts';
import { MathLevel, AiDifficulty, SiteSettings } from '../shared/types.ts';
import { useMobileLandscape } from './hooks/useMobileLandscape.ts';
import { MobileRotateButton } from './components/MobileRotateButton.tsx';
import { RotateDeviceModal } from './components/RotateDeviceModal.tsx';

type AppView = 'main' | 'online' | 'deck' | 'runes' | 'profile' | 'leaderboard' | 'admin';

export function App() {
  const {
    user,
    profile,
    gameState,
    connected,
    searchingMatch,
    lastBustAlert,
    errorMessage,
    loginAsGuest,
    deleteGuestAccount,
    login,
    register,
    logout,
    startAiGame,
    createRoom,
    joinRoom,
    startQuickMatch,
    cancelQuickMatch,
    chooseDraftRune,
    drawCard,
    submitAnswer,
    bank,
    useRune,
    surrender,
    exitGame,
    updateEquippedRunes,
    updateAvatar,
    refreshProfile,
  } = useGameSocket();

  const [currentView, setCurrentView] = useState<AppView>('main');
  const [mathLevel, setMathLevel] = useState<MathLevel>('CO_BAN');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [howToPlayOpen, setHowToPlayOpen] = useState(false);
  const [themeModalOpen, setThemeModalOpen] = useState(false);
  const [currentTheme, setCurrentTheme] = useState<ThemeDef>(getSavedTheme());
  const [siteSettings, setSiteSettings] = useState<SiteSettings | null>(null);
  const {
    isMobile,
    isLandscape,
    isWidescreenCompact,
    isInIframe,
    showRotateDialog,
    toggleLandscape,
    toggleWidescreenCompact,
    openExternalBrowser,
    closeRotateDialog,
  } = useMobileLandscape();

  // Fetch public site settings (guide link, package prices, etc.)
  useEffect(() => {
    fetch('/api/settings')
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (data) setSiteSettings(data); })
      .catch(() => {});
  }, []);

  const handleSelectTheme = (theme: ThemeDef) => {
    const saved = saveTheme(theme.id);
    setCurrentTheme(saved);
  };

  const handleToggleLightMode = () => {
    if (currentTheme.isLight) {
      const darkTheme = GAME_THEMES.find(t => t.id === 'graphite') || GAME_THEMES[0];
      handleSelectTheme(darkTheme);
    } else {
      const lightTheme = GAME_THEMES.find(t => t.id === 'light_pure') || GAME_THEMES[3];
      handleSelectTheme(lightTheme);
    }
  };

  // Auto initialize guest account on first load if no user
  useEffect(() => {
    if (!user) {
      loginAsGuest();
    }
  }, [user, loginAsGuest]);

  return (
    <div
      style={{ backgroundColor: currentTheme.bgHex }}
      className="min-h-screen text-[var(--text-primary)] flex flex-col selection:bg-[var(--accent-subtle)] selection:text-[var(--text-primary)] transition-colors duration-150 relative"
    >
      <AtmosphericBackground lowGraphics={true} />

      {/* Floating Mobile Rotation Button for Phones */}
      <MobileRotateButton
        isLandscape={isLandscape}
        isInIframe={isInIframe}
        onToggle={toggleLandscape}
        onOpenExternal={openExternalBrowser}
      />

      {/* Rotate Device Instruction & Action Modal */}
      <RotateDeviceModal
        isOpen={showRotateDialog}
        onClose={closeRotateDialog}
        isInIframe={isInIframe}
        isWidescreenCompact={isWidescreenCompact}
        onToggleCompact={toggleWidescreenCompact}
        onOpenExternal={openExternalBrowser}
      />

      {/* Top Navbar */}
      <Header
        user={user}
        profile={profile}
        connected={connected}
        onOpenAuth={() => setAuthModalOpen(true)}
        onLogout={logout}
        onNavigateHome={() => {
          if (!gameState) setCurrentView('main');
        }}
        currentView={currentView}
        currentTheme={currentTheme}
        onOpenThemeModal={() => setThemeModalOpen(true)}
        onToggleLightMode={handleToggleLightMode}
        onOpenHowToPlay={() => setHowToPlayOpen(true)}
        onDeleteGuestAccount={deleteGuestAccount}
        isLandscape={isLandscape}
        onToggleLandscape={toggleLandscape}
      />

      {/* Main Container */}
      <main className="flex-1">
        {/* If GAME IS ACTIVE: show Game Arena */}
        {gameState ? (
          <GameArena
            gameState={gameState}
            currentUserId={user?.id || 'guest'}
            onDraw={drawCard}
            onSubmitAnswer={submitAnswer}
            onBank={bank}
            onUseRune={useRune}
            onChooseDraftRune={chooseDraftRune}
            onSurrender={surrender}
            onExit={exitGame}
            lastBustAlert={lastBustAlert}
            errorMessage={errorMessage}
            isLandscape={isLandscape}
            isWidescreenCompact={isWidescreenCompact}
          />
        ) : (
          <>
            {currentView === 'main' && (
              <MainMenu
                onStartAi={(diff, level) => startAiGame(diff, level)}
                onOpenOnline={() => setCurrentView('online')}
                onOpenDeck={() => setCurrentView('deck')}
                onOpenRunes={() => setCurrentView('runes')}
                onOpenProfile={() => setCurrentView('profile')}
                onOpenLeaderboard={() => setCurrentView('leaderboard')}
                onOpenAdmin={() => setCurrentView('admin')}
                onOpenHowToPlay={() => setHowToPlayOpen(true)}
                mathLevel={mathLevel}
                onSetMathLevel={setMathLevel}
                user={user}
                profile={profile}
                onOpenAuth={() => setAuthModalOpen(true)}
                onLogout={logout}
                onDeleteGuestAccount={deleteGuestAccount}
              />
            )}

            {currentView === 'online' && (
              <OnlineLobby
                onBack={() => setCurrentView('main')}
                onQuickMatch={(level) => startQuickMatch(level)}
                onCancelQuickMatch={cancelQuickMatch}
                searchingMatch={searchingMatch}
                onCreateRoom={(level) => createRoom(level)}
                onJoinRoom={(code) => joinRoom(code)}
                mathLevel={mathLevel}
                onSetMathLevel={setMathLevel}
              />
            )}

            {currentView === 'deck' && (
              <DeckViewer onBack={() => setCurrentView('main')} />
            )}

            {currentView === 'runes' && (
              <RuneGrimoire
                equippedRunes={profile?.equippedRunes || []}
                onUpdateRunes={updateEquippedRunes}
                onBack={() => setCurrentView('main')}
              />
            )}

            {currentView === 'profile' && (
              <ProfileView
                profile={profile}
                onBack={() => setCurrentView('main')}
                onUpdateAvatar={updateAvatar}
                onRefreshProfile={refreshProfile}
                isGuest={user?.role === 'guest' || !!user?.username?.startsWith('Pháp Sư #')}
                onDeleteGuestAccount={deleteGuestAccount}
              />
            )}

            {currentView === 'leaderboard' && (
              <LeaderboardView
                onBack={() => setCurrentView('main')}
                currentUserId={user?.id}
              />
            )}

            {currentView === 'admin' && (
              <AdminPanel
                onBack={() => setCurrentView('main')}
                currentUserRole={user?.role}
              />
            )}
          </>
        )}
      </main>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onLogin={login}
        onRegister={register}
        onGuestLogin={loginAsGuest}
      />

      {/* How To Play Modal */}
      <HowToPlayModal
        isOpen={howToPlayOpen}
        onClose={() => setHowToPlayOpen(false)}
        guideLink={siteSettings?.guideLink}
      />

      {/* Theme Background Modal */}
      <ThemeModal
        isOpen={themeModalOpen}
        onClose={() => setThemeModalOpen(false)}
        currentTheme={currentTheme}
        onSelectTheme={handleSelectTheme}
      />
    </div>
  );
}

export default App;
